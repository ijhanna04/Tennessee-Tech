/*
    Title:      lab1.cpp
    Author:     Ian Hanna
    Date        January 2023
    Purpose:    Convert Celsius to Farenheit
*/

#include <iostream>
using namespace std;

int main()
{
    double farenheit, celsius;
    cout << "\n\nWhat is the temperature in Celsius? ";
    cin >> celsius;
    farenheit = celsius * (9.0/5.0) + 32;
    cout << "\nRESULT: " << celsius << " degrees Celsius is ";
    cout << farenheit << " degrees Farenheit.\n\n";
    return 0;
}