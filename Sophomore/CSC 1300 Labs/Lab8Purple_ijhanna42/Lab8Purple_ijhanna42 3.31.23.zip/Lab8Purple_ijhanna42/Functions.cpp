#include "Spells.h"

void getInfoFromUser(string spellNamesINFO[SIZE], int effectAmountINFO[SIZE]){
    for(int i; i < SIZE; i++){
        cout << left << "SPELL " << i + 1;
        cout << right << "\nNAME - ";
        cin >> spellNamesINFO[i];
        cout << right << "\nEFFECT - ";
        cin >> effectAmountINFO[i];
    }
}

double calculateAverage(int effectAmountAVE[SIZE]){
double total = 0;
    for (int i = 0; i < SIZE; i++){
        total += effectAmountAVE[i];
    }
    double average = total / SIZE;
    return average;
}

int findLowest(int effectAmountLOW[SIZE]){
int minValue = effectAmountLOW[0];
    for (int i = 0; i < SIZE; i++){
        if(effectAmountLOW[i] < minValue){
            minValue = effectAmountLOW[i];
        }
    }
    return minValue;
}

int findHighest(int effectAmountHIGH[SIZE]){
int maxValue = effectAmountHIGH[0];
    for (int i = 0; i < SIZE; i++){
        if(effectAmountHIGH[i] > maxValue){
            maxValue = effectAmountHIGH[i];
        }
    }
    return maxValue;
}