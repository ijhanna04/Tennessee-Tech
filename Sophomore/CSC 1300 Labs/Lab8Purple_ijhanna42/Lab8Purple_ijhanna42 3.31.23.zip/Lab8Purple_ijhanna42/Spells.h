#ifndef SPELLS_H
#define SPELLS_H

#include <iostream>
using namespace std;

const int SIZE = 10;

void getInfoFromUser(string, int);
double calculateAverage(int);
int findLowest(int);
int findHighest(int);

#endif