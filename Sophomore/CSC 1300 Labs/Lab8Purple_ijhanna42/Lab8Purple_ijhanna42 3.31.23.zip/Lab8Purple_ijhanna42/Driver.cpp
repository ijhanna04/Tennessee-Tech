/*
    Title:      lab8.cpp
    Author:     Ian Hanna
    Date        March 2023
    Purpose:    Arrays and Functions
*/

#include "Spells.h"

int main(){
    string spellNames[SIZE];
    int effectAmount[SIZE];
    double effectAverage;
    string lineOfDashes(60, '-');

    cout << "Welcome to the Hogwarts School of Witchcraft and Wizardry.\n";
    cout << "\nThis is the Hogwarts Spell Evaluation program.\n";
    cout << "\nPlease enter the spell(s) that you have learned.\n";

    getInfoFromUser(spellNames[SIZE - 1], effectAmount[SIZE - 1]);
    calculateAverage(effectAmount[SIZE - 1]);
    int lowest = findLowest(effectAmount[SIZE - 1]);
    int highest = findHighest(effectAmount[SIZE - 1]);



    cout << lineOfDashes;
    cout << "The average amount of effect of spells: ";
    cout << "\n\nThe spell with the lowest amount of effect is " << "2" << " with value of " << lowest << ".\n";
    cout << "\nThe spell with the highest amount of effect is " << "3" << " with value of " << highest << ".\n";

    return 0;
}