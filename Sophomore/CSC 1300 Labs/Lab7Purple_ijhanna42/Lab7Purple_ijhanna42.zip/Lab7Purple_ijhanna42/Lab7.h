#ifndef LAB7_H
#define LAB7_H

#include <iostream>
using namespace std;

    // function prototypes
    void getData(string&, int&, string&, string&, int&, string&);
    bool calculateResults(int, int, string, int, int, string);
    

#endif