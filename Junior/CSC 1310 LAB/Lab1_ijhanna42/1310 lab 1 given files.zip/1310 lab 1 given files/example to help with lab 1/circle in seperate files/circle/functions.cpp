#include "circle.h"
#include <iostream>
using namespace std;

int howManyCircles()
{
	int numCircles;
	cout << "\n\nHow many circles do you have?";
	cin >> numCircles;
	return numCircles;
}